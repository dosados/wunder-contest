"""
Перебор конфигураций TransformerModel и выбор лучшей по метрике weighted Pearson на валидации.
Использует train_epoch, validate и get_criterion из trainer.py.
Сохраняет для каждого конфига: конфиг с лучшей метрикой и лучшие веса в папку saves.
"""
import os
import sys
import json
import logging
import itertools
from copy import deepcopy
from datetime import datetime
from typing import List, Tuple

import torch
from torch.utils.data import DataLoader

CURRENT_DIR = os.path.dirname(os.path.abspath(__file__))
if CURRENT_DIR not in sys.path:
    sys.path.insert(0, CURRENT_DIR)

from trainer import train_epoch, validate, get_criterion
from constants import (
    DEVICE,
    FEATURE_COLUMNS,
    TARGET_COLUMNS,
    INPUT_DIM,
    TARGET_DIM,
    TRAIN_PATH,
    VAL_PATH,
    SEQUENCE_BATCH_SIZE,
    EPOCHS,
    LR,
    GRAD_CLIP_NORM,
    LR_MIN,
    WARMUP_STEPS,
    ROOT,
    BEST_PARAMS_PATH,
    BEST_VAL_PEARSON_KEY,
)
from model import TransformerModel
from dataset import ParquetSequenceDataset

# Папка для сохранения конфигов и весов гиперпоиска (уникальная подпапка на каждый запуск)
SAVES_DIR = os.path.join(ROOT, "saves")

logging.basicConfig(
    level=logging.INFO,
    format="[%(levelname)s] %(message)s",
)
log = logging.getLogger(__name__)


def _build_transformer_config(
    d_model: int,
    num_heads: int,
    dim_feedforward: int,
    num_layers: int,
    dropout: float,
) -> dict:
    """Собирает конфиг для TransformerModel из переданных параметров."""
    return {
        "input_dim": INPUT_DIM,
        "d_model": d_model,
        "num_heads": num_heads,
        "dim_feedforward": dim_feedforward,
        "num_layers": num_layers,
        "dropout": dropout,
        "num_classes": TARGET_DIM,
    }


def _config_slug(config: dict) -> str:
    """Короткое читаемое имя конфига для имени папки (d_model, num_heads, layers, dropout)."""
    return "d{}_{}_l{}_do{}".format(
        config.get("d_model", ""),
        config.get("num_heads", ""),
        config.get("num_layers", ""),
        config.get("dropout", 0),
    )


def get_config_grid():

    d_models = [48, 64, 80]
    num_heads_list = [2, 4, 8]
    dim_feedforward_list = [64, 128, 80]
    num_layers_list = [2, 4]
    dropouts = [0.1]

    configs = []
    for d_model, num_heads, dim_ff, num_layers, dropout in itertools.product(
        d_models,
        num_heads_list,
        dim_feedforward_list,
        num_layers_list,
        dropouts,
    ):
        if dim_ff < d_model:
            continue
        if d_model % num_heads != 0:
            continue
        configs.append(
            _build_transformer_config(
                d_model=d_model,
                num_heads=num_heads,
                dim_feedforward=dim_ff,
                num_layers=num_layers,
                dropout=dropout,
            )
        )
    return configs


def run_single_config(
    config: dict,
    train_loader: DataLoader,
    val_loader: DataLoader,
    epochs: int,
    save_path: str = None,
) -> Tuple[dict, float]:
    """
    Обучает TransformerModel с заданным config и возвращает (config, best_val_pearson).
    Использует train_epoch и validate из trainer.
    """
    criterion = get_criterion()
    model = TransformerModel(config=config).to(DEVICE)
    optimizer = torch.optim.Adam(model.parameters(), lr=LR)
    total_train_batches = len(train_loader)
    total_steps = epochs * total_train_batches
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(
        optimizer, T_max=total_steps, eta_min=LR_MIN
    )

    total_val_batches = len(val_loader) if val_loader is not None else 0
    best_val_pearson = -float("inf")

    for epoch in range(1, epochs + 1):
        train_epoch(
            model,
            train_loader,
            optimizer,
            scheduler,
            criterion,
            DEVICE,
            epoch=epoch,
            total_epochs=epochs,
            total_batches=total_train_batches,
        )
        if val_loader is not None:
            _, val_pearson = validate(
                model,
                val_loader,
                criterion,
                DEVICE,
                epoch=epoch,
                total_epochs=epochs,
                total_val_batches=total_val_batches,
            )
            log.info("Epoch %d/%d val Pearson: %.6f", epoch, epochs, val_pearson)
            if val_pearson > best_val_pearson:
                best_val_pearson = val_pearson
                if save_path:
                    os.makedirs(os.path.dirname(save_path) or ".", exist_ok=True)
                    torch.save(model.state_dict(), save_path)
                    log.debug("Saved best weights (val Pearson %.6f) to %s", val_pearson, save_path)

    return (config, best_val_pearson if val_loader is not None else -float("inf"))


def run_hyperparameter_search(
    configs: List[dict] = None,
    epochs_per_config: int = None,
    max_configs: int = None,
    saves_dir: str = None,
) -> dict:
    """
    Перебирает конфиги, обучает модель для каждого, определяет лучший по val weighted Pearson.
    Для каждого конфига сохраняет в saves: конфиг с лучшей метрикой и только лучшие веса.
    Возвращает лучший конфиг (с полем best_val_pearson).
    """
    if configs is None:
        configs = get_config_grid()
    if epochs_per_config is None:
        epochs_per_config = min(EPOCHS, 10)
    if max_configs is not None:
        configs = configs[:max_configs]
    if saves_dir is None:
        saves_dir = SAVES_DIR

    if not os.path.isfile(TRAIN_PATH):
        log.error("Train file not found: %s", TRAIN_PATH)
        return {}

    # Уникальная папка на этот запуск (чтобы не перезаписывать разные запуски)
    run_name = "run_{}".format(datetime.now().strftime("%Y%m%d_%H%M%S"))
    run_dir = os.path.join(saves_dir, run_name)
    os.makedirs(run_dir, exist_ok=True)
    log.info("Saving configs and weights to %s", run_dir)

    train_ds = ParquetSequenceDataset(
        TRAIN_PATH,
        feature_columns=FEATURE_COLUMNS,
        target_columns=TARGET_COLUMNS,
    )
    train_loader = DataLoader(
        train_ds,
        batch_size=SEQUENCE_BATCH_SIZE,
        shuffle=True,
        num_workers=0,
        pin_memory=(DEVICE == "cuda"),
    )

    val_loader = None
    if VAL_PATH and os.path.isfile(VAL_PATH):
        val_ds = ParquetSequenceDataset(
            VAL_PATH,
            feature_columns=FEATURE_COLUMNS,
            target_columns=TARGET_COLUMNS,
        )
        val_loader = DataLoader(
            val_ds,
            batch_size=SEQUENCE_BATCH_SIZE,
            shuffle=False,
            num_workers=0,
        )
        log.info("Validation from %s", VAL_PATH)
    else:
        log.warning("No validation set; best config will be chosen by train loss only (not recommended)")

    results: List[Tuple[dict, float]] = []
    for i, config in enumerate(configs):
        log.info("Config %d/%d: %s", i + 1, len(configs), config)
        # Уникальная подпапка для конфига: config_<i>_<slug>, чтобы не перезаписывать другие конфиги
        slug = _config_slug(config)
        config_dir_name = "config_{:04d}_{}".format(i, slug)
        config_dir = os.path.join(run_dir, config_dir_name)
        os.makedirs(config_dir, exist_ok=True)
        save_path = os.path.join(config_dir, "best_weights.pt")

        cfg_copy = deepcopy(config)
        _, best_pearson = run_single_config(
            cfg_copy,
            train_loader,
            val_loader,
            epochs=epochs_per_config,
            save_path=save_path,
        )
        results.append((config, best_pearson))

        # Сохраняем конфиг с лучшей метрикой для этого конфига
        config_with_metric = deepcopy(config)
        config_with_metric[BEST_VAL_PEARSON_KEY] = best_pearson
        config_json_path = os.path.join(config_dir, "config.json")
        with open(config_json_path, "w", encoding="utf-8") as f:
            json.dump(config_with_metric, f, indent=2, ensure_ascii=False)
        log.info("Config %d best val Pearson: %.6f (saved to %s)", i + 1, best_pearson, config_dir)

    best_pair = max(results, key=lambda x: x[1])
    best_config, best_pearson = best_pair
    best_config_out = deepcopy(best_config)
    best_config_out[BEST_VAL_PEARSON_KEY] = best_pearson

    # Сохраняем сводку: какой конфиг лучший по всему запуску
    summary_path = os.path.join(run_dir, "best_config_summary.json")
    with open(summary_path, "w", encoding="utf-8") as f:
        json.dump(best_config_out, f, indent=2, ensure_ascii=False)
    log.info("Best config: %s with %s = %.6f (summary in %s)", best_config_out, BEST_VAL_PEARSON_KEY, best_pearson, summary_path)
    return best_config_out


def main():
    import argparse
    parser = argparse.ArgumentParser(description="Hyperparameter search for TransformerModel")
    parser.add_argument("--epochs", type=int, default=10, help="Epochs per config")
    parser.add_argument("--max-configs", type=int, default=None, help="Limit number of configs to try")
    parser.add_argument(
        "--save",
        type=str,
        default=None,
        help="Optional path to copy best config JSON (by default only in saves/run_xxx/best_config_summary.json)",
    )
    parser.add_argument("--saves-dir", type=str, default=SAVES_DIR, help="Directory for saves (default: ROOT/saves)")
    args = parser.parse_args()

    best = run_hyperparameter_search(
        epochs_per_config=args.epochs,
        max_configs=args.max_configs,
        saves_dir=args.saves_dir,
    )
    if best and args.save:
        os.makedirs(os.path.dirname(args.save) or ".", exist_ok=True)
        with open(args.save, "w", encoding="utf-8") as f:
            json.dump(best, f, indent=2, ensure_ascii=False)
        log.info("Saved best config copy to %s", args.save)


if __name__ == "__main__":
    main()
