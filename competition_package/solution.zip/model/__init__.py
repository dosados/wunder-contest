"""
Hybrid Conv + Transformer модель для предсказания состояния рынка.
Архитектура: description.md.
"""

from .transformer_model import TransformerModel

__all__ = ["TransformerModel"]
