import torch
import torch.nn as nn

from constants import transformer_constants


class TransformerBlocks(nn.Module):
    def __init__(self, constants=None):
        super().__init__()
        cfg = constants if constants is not None else transformer_constants
        input_dim = cfg["input_dim"]
        d_model = cfg["d_model"]
        num_heads = cfg["num_heads"]
        dim_feedforward = cfg["dim_feedforward"]
        num_layers = cfg["num_layers"]
        dropout = cfg.get("dropout", 0.1)
        num_classes = cfg["num_classes"]

        self.input_proj = nn.Linear(input_dim, d_model)
        self.proj_norm = nn.LayerNorm(d_model)

        encoder_layer = nn.TransformerEncoderLayer(
            d_model=d_model,
            nhead=num_heads,
            dim_feedforward=dim_feedforward,
            dropout=dropout,
            activation="gelu",
            batch_first=True,  # (B, T, d_model)
            norm_first=False,
        )
        self.transformer = nn.TransformerEncoder(encoder_layer, num_layers=num_layers)

        self.norm = nn.LayerNorm(d_model)
        self.head = nn.Linear(d_model, num_classes)
        self.skip = nn.Linear(input_dim, num_classes)

    def forward(self, x):
        # x: (B, T, input_dim)
        h = self.input_proj(x)
        h = self.proj_norm(h)
        h = self.transformer(h)  # (B, T, d_model)
        h = self.norm(h)
        return self.head(h) + self.skip(x)
