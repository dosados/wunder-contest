"""
TransformerModel: обёртка над TransformerBlocks с поддержкой streaming (forward по шагам с seq_ix).
Обучение: forward_sequence(B, T, D) -> (B, T, num_classes).
Инференс: forward(x, seq_ix) — накопление по seq_ix и предсказание на последнем шаге.
"""
import torch
import torch.nn as nn

from constants import transformer_constants, SEQ_LEN
from .transformer_blocks import TransformerBlocks


class TransformerModel(nn.Module):
    def __init__(self, config=None):
        super().__init__()
        cfg = config if config is not None else transformer_constants
        self.backbone = TransformerBlocks(constants=cfg)
        self._max_seq_len = SEQ_LEN
        self._input_dim = cfg["input_dim"]
        self._seq_buffer = {}
        self._current_seq_ix = None

    def forward(self, x: torch.Tensor, seq_ix: int = None):
        if seq_ix is not None and seq_ix != self._current_seq_ix:
            self._current_seq_ix = seq_ix
            self._seq_buffer.clear()
        if x.dim() == 1:
            x = x.unsqueeze(0)
        key = self._current_seq_ix if self._current_seq_ix is not None else 0
        if key not in self._seq_buffer:
            self._seq_buffer[key] = (
                x.new_zeros(1, self._max_seq_len, self._input_dim),
                0,
            )
        buf, length = self._seq_buffer[key]
        n = x.size(0)
        buf[0, length : length + n].copy_(x)
        length += n
        self._seq_buffer[key] = (buf, length)
        seq = buf[:, :length, :]
        out = self.backbone(seq)
        return out.squeeze(0)

    def forward_sequence(self, x: torch.Tensor) -> torch.Tensor:
        return self.backbone(x)

    def reset_state(self):
        self._seq_buffer.clear()
        self._current_seq_ix = None
