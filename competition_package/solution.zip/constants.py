"""
Общие константы: устройство, пути, размерности данных и гиперпараметры моделей.
"""
import os
from torch.cuda import is_available

DEVICE = "cuda" if is_available() else "cpu"

# --- Корень решения (папка our_solution) ---
ROOT = os.path.dirname(os.path.abspath(__file__))
PKG = os.path.dirname(ROOT)

# --- Данные: колонки и размерности ---
FEATURE_COLUMNS = (
    [f"p{i}" for i in range(12)]
    + [f"v{i}" for i in range(12)]
    + [f"dp{i}" for i in range(4)]
    + [f"dv{i}" for i in range(4)]
)
TARGET_COLUMNS = ["t0", "t1"]
INPUT_DIM = len(FEATURE_COLUMNS)  # 32
TARGET_DIM = len(TARGET_COLUMNS)   # 2

# --- Пути к датасетам ---
DATASETS_DIR = os.path.join(ROOT, "..", "datasets")
TRAIN_PATH = os.path.join(DATASETS_DIR, "train.parquet")
VAL_PATH = os.path.join(DATASETS_DIR, "valid.parquet")

# --- Обучение: веса и сохранение ---
WEIGHTS_DIR = os.path.join(ROOT, "weights")
SAVE_NAME = "model.pt"

# --- Inference (solution / PredictionModel) ---
CONFIG_PATH = os.path.join(ROOT, "inference", "config.json")
WEIGHTS_PATH = os.path.join(ROOT, "weights", "model.pt")

# --- Гиперпоиск ---
BEST_PARAMS_PATH = os.path.join(ROOT, "best_hyperparameters.json")
BEST_WEIGHTS_NAME = "model4_best_search.pt"

# --- Inference train_best ---
INFERENCE_DIR = os.path.join(ROOT, "inference")
INFERENCE_WEIGHTS_DIR = os.path.join(INFERENCE_DIR, "weights")
INFERENCE_CONFIG_PATH = os.path.join(INFERENCE_DIR, "config.json")
INFERENCE_BEST_WEIGHTS_PATH = os.path.join(INFERENCE_WEIGHTS_DIR, "best_model.pt")
BEST_HP_PATH = os.path.join(ROOT, "best_hyperparameters.json")
BEST_VAL_PEARSON_KEY = "best_val_pearson"

# --- Параметры обучения ---
WARMUP_STEPS = 99
SEQUENCE_BATCH_SIZE = 16
EPOCHS = 20
LR = 1e-3
GRAD_CLIP_NORM = 1.0
LR_MIN = 1e-6  # минимальный lr для CosineAnnealingLR

# --- Метрика (weighted Pearson) ---
PRED_CLIP_LOW = -6.0
PRED_CLIP_HIGH = 6.0
WEIGHT_EPS = 1e-8
VAR_EPS = 1e-8

# --- Датасет: последовательности ---
MIN_BATCH_MULTIPLE = 1000
SEQ_LEN = 1000

# --- Гиперпараметры Conv-модели (для solution/config; заполняется из конфига или поиска) ---
convo_constants = {}

# --- Mamba: размерности и архитектура ---
mamba_constants = {
    "input_dim": INPUT_DIM,
    "d_model": 128,
    "d_state": 16,
    "d_conv": 4,
    "expand": 2,
    "num_layers": 4,
    "num_classes": TARGET_DIM,
}

# --- Transformer: размерности и архитектура ---
transformer_constants = {
    "input_dim": INPUT_DIM,
    "d_model": 48,
    "num_heads": 2,
    "dim_feedforward": 64,
    "num_layers": 2,
    "dropout": 0.1,
    "num_classes": TARGET_DIM,
}
