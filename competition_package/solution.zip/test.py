"""
Проверка работоспособности: загружает PredictionModel из solution.py и прогоняет одну
последовательность из 1000 шагов по одному (как при инференсе).
Выводит предсказания и настоящие t0, t1 из датасета.
Запуск из папки our_solution: python test.py
"""
import os
import sys

CURRENT_DIR = os.path.dirname(os.path.abspath(__file__))
if CURRENT_DIR not in sys.path:
    sys.path.insert(0, CURRENT_DIR)

import numpy as np
from solution import PredictionModel
from utils import DataPoint
from constants import TRAIN_PATH, VAL_PATH, FEATURE_COLUMNS, TARGET_COLUMNS
from dataset import ParquetSequenceDataset

SEQ_LEN = 1000


def main():
    print("Loading PredictionModel (config + weights from constants paths)...")
    model = PredictionModel()
    print("OK.")

    # Берём одну последовательность из датасета (valid если есть, иначе train)
    data_path = VAL_PATH if os.path.isfile(VAL_PATH) else TRAIN_PATH
    if not os.path.isfile(data_path):
        print(f"Dataset not found: {data_path}. Put train.parquet or valid.parquet in competition_package/datasets/")
        sys.exit(1)
    ds = ParquetSequenceDataset(data_path, feature_columns=list(FEATURE_COLUMNS), target_columns=list(TARGET_COLUMNS))
    x, y = ds[0]  # x: (1000, 32), y: (1000, 2) — настоящие t0, t1
    x_np = x.numpy().astype(np.float64)
    y_np = y.numpy()

    print(f"Running one sequence of {SEQ_LEN} steps from {os.path.basename(data_path)} (one step at a time).\n")

    predictions = []
    for step in range(SEQ_LEN):
        dp = DataPoint(
            seq_ix=0,
            step_in_seq=step,
            need_prediction=True,
            state=x_np[step],
        )
        pred = model.predict(dp)
        predictions.append(pred)

    predictions = np.array(predictions)
    t0_true = y_np[:, 0]
    t1_true = y_np[:, 1]
    print(f"step  | pred_t0     pred_t1     | true_t0      true_t1\n" + "-" * 55)
    for step in range(SEQ_LEN):
        print(
            f"  {step:4d} | {predictions[step, 0]:+.6f}  {predictions[step, 1]:+.6f}  | "
            f"{t0_true[step]:+.6f}  {t1_true[step]:+.6f}"
        )
    print("\nDone. Model is operational.")

if __name__ == "__main__":
    main()
