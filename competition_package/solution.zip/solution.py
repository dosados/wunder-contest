import os
import sys
import json
from typing import Optional

import numpy as np
import torch

from constants import ROOT, PKG

# ROOT первым, чтобы utils, model, dataset импортировались из our_solution
for path in (PKG, ROOT):
    if path not in sys.path:
        sys.path.insert(0, path)

from constants import CONFIG_PATH, WEIGHTS_PATH, PRED_CLIP_LOW, PRED_CLIP_HIGH, INPUT_DIM
from utils import DataPoint


def _apply_config(config: dict) -> None:
    import constants
    for k in (
        "input_dim",
        "d_model",
        "num_heads",
        "dim_feedforward",
        "num_layers",
        "dropout",
        "num_classes",
    ):
        if k in config:
            constants.transformer_constants[k] = config[k]


def _load_transformer_model(config_path: str, weights_path: str):
    if os.path.isfile(config_path):
        with open(config_path, "r", encoding="utf-8") as f:
            data = json.load(f)
        config = data.get("best_hyperparameters", data) if isinstance(data, dict) else data
        _apply_config(config)
    from model import TransformerModel
    from constants import DEVICE
    model = TransformerModel()
    model.load_state_dict(torch.load(weights_path, map_location="cpu"), strict=True)
    model = model.to(DEVICE)
    model.eval()
    return model


class PredictionModel:


    def __init__(self):
        self._model = _load_transformer_model(CONFIG_PATH, WEIGHTS_PATH)
        dev = next(self._model.parameters()).device
        self._input_buf = torch.zeros(1, INPUT_DIM, device=dev, dtype=torch.float32)

    def predict(self, data_point: DataPoint) -> Optional[np.ndarray]:
        if not data_point.need_prediction:
            return None
        dev = next(self._model.parameters()).device
        if dev.type == "cpu":
            np.copyto(
                self._input_buf[0].numpy(),
                np.ascontiguousarray(data_point.state, dtype=np.float32),
            )
        else:
            self._input_buf[0].copy_(
                torch.as_tensor(data_point.state, dtype=torch.float32, device=dev)
            )
        x = self._input_buf
        with torch.inference_mode():
            out = self._model.forward(x, seq_ix=data_point.seq_ix)
        if out.dim() == 2:
            out = out[-1]
        pred = out.cpu().numpy().flatten()
        return np.clip(pred, PRED_CLIP_LOW, PRED_CLIP_HIGH).astype(np.float64)


__all__ = ["PredictionModel", "DataPoint"]
